---
name: financial-analysis
description: This skill should be used when analyzing financial statements, calculating financial metrics and ratios, assessing company financial health, or performing fundamental analysis. Triggers include requests to analyze income statements, balance sheets, cash flow statements, calculate profitability/liquidity/leverage ratios, or evaluate company valuation.
---

# Financial Analysis

## Overview

Perform comprehensive financial statement analysis using professional analyst methodologies. This skill provides systematic workflows for calculating and interpreting financial metrics, from basic profitability ratios to advanced quality of earnings indicators.

## Workflow Decision Tree

Follow this decision tree to determine the appropriate analysis approach:

1. **Initial Request Analysis**: What aspect of financial performance is being analyzed?
   - Overall company health → Proceed to Comprehensive Analysis workflow
   - Specific metric category (profitability, liquidity, etc.) → Proceed to Targeted Analysis workflow
   - Valuation question → Proceed to Valuation Analysis workflow
   - Earnings quality concerns → Proceed to Quality Analysis workflow

2. **Data Availability**: What financial statements are available?
   - Complete financials (Income Statement, Balance Sheet, Cash Flow) → Full analysis possible
   - Partial data → Focus on metrics calculable with available data
   - Need definitions → Reference `references/financial_metrics.md`

3. **Industry Context**: Is industry context needed?
   - Yes → Include industry benchmarks and comparisons in analysis
   - No → Provide absolute metrics with general benchmarks

## Core Analysis Workflows

### 1. Comprehensive Financial Analysis

Execute this workflow when asked to perform a full financial health assessment.

**Step 1: Gather Financial Data**
- Identify and extract key line items from all three financial statements
- Note the reporting period and verify data consistency
- Calculate derived items (e.g., EBITDA, Net Working Capital)

**Step 2: Calculate Core Metrics by Category**

Calculate metrics in this order, referencing `references/financial_metrics.md` for formulas:

a) **Profitability Metrics** (most fundamental)
   - Gross Profit Margin
   - Operating Profit Margin
   - Net Profit Margin
   - EBITDA Margin
   - Return on Assets (ROA)
   - Return on Equity (ROE)
   - Return on Invested Capital (ROIC)

b) **Liquidity Metrics** (immediate financial health)
   - Current Ratio
   - Quick Ratio
   - Cash Ratio
   - Working Capital
   - Operating Cash Flow Ratio

c) **Leverage Metrics** (financial risk)
   - Debt-to-Equity Ratio
   - Debt-to-Assets Ratio
   - Interest Coverage Ratio
   - Debt Service Coverage Ratio
   - Net Debt to EBITDA

d) **Efficiency Metrics** (operational effectiveness)
   - Asset Turnover
   - Inventory Turnover / Days Inventory Outstanding
   - Receivables Turnover / Days Sales Outstanding
   - Payables Turnover / Days Payable Outstanding
   - Cash Conversion Cycle

e) **Cash Flow Metrics** (quality of earnings)
   - Free Cash Flow (FCF)
   - Operating Cash Flow Margin
   - Quality of Earnings Ratio
   - Cash Flow to Debt Ratio

**Step 3: Analyze Results**
- Compare metrics to industry benchmarks from `references/financial_metrics.md`
- Identify strengths and weaknesses
- Look for red flags or concerning trends
- Assess metric relationships (e.g., ROE vs ROA to understand leverage impact)

**Step 4: Synthesize Insights**
- Provide clear summary of financial health
- Highlight key findings with supporting metrics
- Note areas of concern or competitive advantage
- Make actionable observations

### 2. Targeted Analysis (Specific Metric Categories)

When asked to focus on a specific aspect:

**For Profitability Analysis:**
- Calculate all margin metrics (Gross, Operating, Net, EBITDA)
- Calculate all return metrics (ROA, ROE, ROIC, ROC)
- Perform DuPont analysis to decompose ROE drivers
- Assess whether returns come from operations vs. leverage

**For Liquidity Analysis:**
- Calculate Current, Quick, and Cash ratios
- Assess Working Capital position
- Calculate Defensive Interval Ratio
- Evaluate Cash Conversion Cycle
- Determine ability to meet short-term obligations

**For Leverage/Solvency Analysis:**
- Calculate debt ratios (D/E, D/A, D/C)
- Calculate coverage ratios (Interest, Debt Service, Fixed Charge)
- Assess Net Debt to EBITDA
- Evaluate sustainability of capital structure

**For Efficiency Analysis:**
- Calculate turnover ratios for all major asset categories
- Calculate days metrics (DIO, DSO, DPO)
- Assess Cash Conversion Cycle
- Evaluate asset productivity

### 3. Valuation Analysis

When asked about valuation or whether a stock is fairly priced:

**Step 1: Calculate Valuation Multiples**
- Price-to-Earnings (P/E) Ratio
- Price-to-Book (P/B) Ratio
- Price-to-Sales (P/S) Ratio
- EV/EBITDA
- EV/Sales
- PEG Ratio (if growth data available)

**Step 2: Compare to Industry Benchmarks**
- Reference appropriate industry ranges from `references/financial_metrics.md`
- Identify whether metrics suggest undervaluation or overvaluation
- Consider company lifecycle stage in interpretation

**Step 3: Assess Valuation Justification**
- High P/E justified by growth? Calculate PEG
- High P/B justified by returns? Check ROE
- Compare profitability margins to valuation premium

### 4. Quality of Earnings Analysis

When asked to assess earnings quality or sustainability:

**Step 1: Compare Cash Flow to Earnings**
- Calculate Quality of Earnings Ratio (OCF / Net Income)
- Should be ≥ 1.0 for high-quality earnings
- Ratios consistently < 0.8 are red flags

**Step 2: Analyze Accruals**
- Calculate Accruals Ratio: (Net Income - OCF) / Average Assets
- < 5% is high quality, > 10% raises concerns
- High accruals suggest earnings from accounting vs. cash

**Step 3: Check Working Capital Trends**
- Are receivables growing faster than sales? (collection issues)
- Are inventories building? (obsolescence risk)
- Are payables stretching? (cash flow stress)

**Step 4: Examine Revenue and Expense Quality**
- Is revenue recurring or one-time?
- Are there frequent "non-recurring" charges?
- Compare GAAP earnings to "adjusted" earnings

## Best Practices

### Always Provide Context
- State which financial statement line items were used
- Note any assumptions made in calculations
- Indicate when data is unavailable for certain metrics

### Use Industry Benchmarks
- Reference appropriate industry ranges from `references/financial_metrics.md`
- Note when company metrics fall outside typical ranges
- Explain industry-specific considerations (e.g., utilities naturally have higher leverage)

### Analyze Trends, Not Just Snapshots
- When historical data is available, calculate metrics over multiple periods
- Identify improving vs. deteriorating trends
- Single-period metrics can be distorted by one-time events

### Consider Business Lifecycle
- Growth companies: May show negative FCF while investing for expansion
- Mature companies: Should show stable margins and positive FCF
- Declining companies: May show artificially high asset turnover

### Watch for Red Flags
Critical warning signs to highlight:
- Cash flow consistently below net income
- Receivables growing much faster than sales
- Declining working capital turnover
- ROE improvement solely from leverage increases
- Debt coverage ratios below industry minimums
- Frequent "non-recurring" charges

### Present Results Clearly
- Use tables for multiple metrics when appropriate
- Highlight key findings and insights
- Explain what metrics mean in plain language
- Provide actionable conclusions

## Resources

### references/financial_metrics.md
Comprehensive reference guide containing:
- Detailed formulas for all financial metrics
- Exact financial statement line items to use
- Industry-specific benchmark ranges
- Interpretation guidelines for each metric
- Red flags and warning signs to watch for

Load this reference when:
- Need exact calculation formulas
- Require industry benchmark ranges
- Want detailed interpretation guidance
- Analyzing complex or uncommon metrics

### Usage Notes

**When to Use This Skill:**
- "Analyze this company's financial statements"
- "Calculate the profitability metrics for X company"
- "Is this company's liquidity position healthy?"
- "What's the quality of their earnings?"
- "Perform a DuPont analysis"
- "Is this stock overvalued or undervalued?"
- "Assess the company's leverage and debt situation"

**When NOT to Use This Skill:**
- General financial planning or personal finance advice
- Tax calculations or accounting entries
- Investment recommendations without financial analysis
- Forecasting future performance (this skill analyzes historical data)
