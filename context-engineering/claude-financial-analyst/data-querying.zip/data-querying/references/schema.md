# Financial Data Schema Reference

This document describes the four financial data tables available in the `users.david_huang` schema for financial analysis queries.

## Overview

All tables use the Unity Catalog three-level namespace: `users.david_huang.<table_name>`

**Available Tables:**
- `users.david_huang.cfa_stock_price` - Daily stock price data
- `users.david_huang.cfa_balance_sheet` - Quarterly/annual balance sheet data
- `users.david_huang.cfa_income_statement` - Quarterly/annual income statement data
- `users.david_huang.cfa_cashflow` - Quarterly/annual cash flow statement data

## Table Schemas

### 1. cfa_stock_price

Daily stock price data including OHLC (Open, High, Low, Close) and volume.

**Columns:**
- `date` (date) - Trading date
- `ticker` (string) - Stock ticker symbol
- `open` (double) - Opening price
- `high` (double) - Highest price during the trading day
- `low` (double) - Lowest price during the trading day
- `close` (double) - Closing price
- `volume` (bigint) - Trading volume

**Primary Keys:** ticker, date

**Common Queries:**
- Latest stock prices for a ticker
- Historical price trends over a date range
- Volume analysis
- Price movements (% change calculations)

### 2. cfa_balance_sheet

Quarterly and annual balance sheet data showing assets, liabilities, and equity.

**Columns:**
- `ticker` (string) - Stock ticker symbol
- `reporting_date` (date) - Financial statement reporting date
- `reportedcurrency` (string) - Currency of reported values

**Assets:**
- `totalassets` (double) - Total assets
- `totalcurrentassets` (double) - Current assets (< 1 year)
- `cashandcashequivalentsatcarryingvalue` (double) - Cash and cash equivalents
- `cashandshortterminvestments` (double) - Cash + short-term investments
- `inventory` (double) - Inventory value
- `currentnetreceivables` (double) - Accounts receivable (net)
- `totalnoncurrentassets` (double) - Non-current assets (> 1 year)
- `propertyplantequipment` (double) - PP&E gross value
- `accumulateddepreciationamortizationppe` (double) - Accumulated depreciation
- `intangibleassets` (double) - Total intangible assets
- `intangibleassetsexcludinggoodwill` (double) - Intangibles excluding goodwill
- `goodwill` (double) - Goodwill value
- `investments` (double) - Total investments
- `longterminvestments` (double) - Long-term investments
- `shortterminvestments` (double) - Short-term investments
- `othercurrentassets` (double) - Other current assets
- `othernoncurrentassets` (double) - Other non-current assets

**Liabilities:**
- `totalliabilities` (double) - Total liabilities
- `totalcurrentliabilities` (double) - Current liabilities (< 1 year)
- `currentaccountspayable` (double) - Accounts payable
- `deferredrevenue` (double) - Unearned revenue
- `currentdebt` (double) - Current portion of debt
- `shorttermdebt` (double) - Short-term debt
- `totalnoncurrentliabilities` (double) - Non-current liabilities (> 1 year)
- `capitalleaseobligations` (double) - Capital lease obligations
- `longtermdebt` (double) - Long-term debt total
- `currentlongtermdebt` (double) - Current portion of long-term debt
- `longtermdebtnoncurrent` (double) - Long-term debt (non-current)
- `shortlongtermdebttotal` (double) - Total short and long-term debt
- `othercurrentliabilities` (double) - Other current liabilities
- `othernoncurrentliabilities` (double) - Other non-current liabilities

**Equity:**
- `totalshareholderequity` (double) - Total shareholder equity
- `treasurystock` (double) - Treasury stock value
- `retainedearnings` (double) - Retained earnings
- `commonstock` (double) - Common stock value
- `commonstocksharesoutstanding` (bigint) - Shares outstanding

**Primary Keys:** ticker, reporting_date

**Common Queries:**
- Asset composition analysis
- Debt levels and leverage ratios
- Working capital calculations (current assets - current liabilities)
- Book value per share
- Liquidity analysis

### 3. cfa_income_statement

Quarterly and annual income statement data showing revenues, expenses, and profitability.

**Columns:**
- `ticker` (string) - Stock ticker symbol
- `reporting_date` (date) - Financial statement reporting date
- `reportedcurrency` (string) - Currency of reported values

**Revenue & Gross Profit:**
- `totalrevenue` (double) - Total revenue/sales
- `costofrevenue` (bigint) - Cost of revenue
- `costofgoodsandservicessold` (bigint) - COGS
- `grossprofit` (bigint) - Gross profit (revenue - COGS)

**Operating Performance:**
- `operatingexpenses` (bigint) - Total operating expenses
- `sellinggeneralandadministrative` (double) - SG&A expenses
- `researchanddevelopment` (double) - R&D expenses
- `operatingincome` (bigint) - Operating income/EBIT

**Other Income/Expenses:**
- `investmentincomenet` (double) - Net investment income
- `netinterestincome` (double) - Net interest income
- `interestincome` (double) - Interest income
- `interestexpense` (bigint) - Interest expense
- `noninterestincome` (double) - Non-interest income
- `othernonoperatingincome` (double) - Other non-operating income
- `interestanddebtexpense` (double) - Interest and debt expense

**Depreciation:**
- `depreciation` (double) - Depreciation expense
- `depreciationandamortization` (double) - D&A expense

**Profitability:**
- `incomebeforetax` (bigint) - Income before tax
- `incometaxexpense` (double) - Income tax expense
- `netincomefromcontinuingoperations` (double) - Net income from continuing ops
- `netincome` (bigint) - Net income (bottom line)
- `comprehensiveincomenetoftax` (double) - Comprehensive income

**Calculated Metrics:**
- `ebit` (double) - Earnings before interest and taxes
- `ebitda` (bigint) - Earnings before interest, taxes, D&A

**Primary Keys:** ticker, reporting_date

**Common Queries:**
- Revenue growth trends
- Profit margin calculations (gross, operating, net)
- Operating efficiency analysis
- Tax rate analysis
- Earnings trends

### 4. cfa_cashflow

Quarterly and annual cash flow statement data showing operating, investing, and financing activities.

**Columns:**
- `ticker` (string) - Stock ticker symbol
- `reporting_date` (date) - Financial statement reporting date
- `reportedcurrency` (string) - Currency of reported values

**Operating Activities:**
- `operatingcashflow` (bigint) - Cash flow from operations
- `paymentsforoperatingactivities` (double) - Cash paid for operations
- `proceedsfromoperatingactivities` (double) - Cash received from operations
- `changeinoperatingliabilities` (double) - Change in operating liabilities
- `changeinoperatingassets` (double) - Change in operating assets
- `changeinreceivables` (double) - Change in accounts receivable
- `changeininventory` (double) - Change in inventory
- `depreciationdepletionandamortization` (bigint) - Non-cash D&A expense
- `profitloss` (double) - Net profit/loss

**Investing Activities:**
- `cashflowfrominvestment` (double) - Cash flow from investing
- `capitalexpenditures` (bigint) - Capital expenditures (CapEx)

**Financing Activities:**
- `cashflowfromfinancing` (bigint) - Cash flow from financing
- `proceedsfromrepaymentsofshorttermdebt` (double) - Short-term debt proceeds/payments
- `proceedsfromissuanceoflongtermdebtandcapitalsecuritiesnet` (double) - Long-term debt issuance
- `dividendpayout` (double) - Total dividends paid
- `dividendpayoutcommonstock` (double) - Common stock dividends
- `dividendpayoutpreferredstock` (double) - Preferred stock dividends
- `paymentsforrepurchaseofcommonstock` (double) - Share buybacks (common)
- `paymentsforrepurchaseofequity` (double) - Total equity repurchases
- `paymentsforrepurchaseofpreferredstock` (double) - Share buybacks (preferred)
- `proceedsfromissuanceofcommonstock` (double) - Common stock issuance
- `proceedsfromissuanceofpreferredstock` (double) - Preferred stock issuance
- `proceedsfromrepurchaseofequity` (double) - Equity repurchase proceeds
- `proceedsfromsaleoftreasurystock` (double) - Treasury stock sale proceeds

**Net Cash Change:**
- `changeincashandcashequivalents` (double) - Net change in cash
- `changeinexchangerate` (double) - FX impact on cash
- `netincome` (bigint) - Net income (for reconciliation)

**Primary Keys:** ticker, reporting_date

**Common Queries:**
- Free cash flow calculation (operating cash flow - CapEx)
- Cash generation trends
- Capital allocation analysis (dividends vs. buybacks vs. debt repayment)
- Working capital changes
- Cash conversion analysis

## Relationships Between Tables

All tables can be joined using:
- **ticker** - Stock ticker symbol
- **reporting_date** / **date** - Temporal key

**Common Join Patterns:**

1. **Price + Fundamentals:**
   ```sql
   SELECT sp.ticker, sp.date, sp.close, bs.totalassets
   FROM users.david_huang.cfa_stock_price sp
   JOIN users.david_huang.cfa_balance_sheet bs
     ON sp.ticker = bs.ticker
     AND sp.date >= bs.reporting_date
   ```

2. **Complete Financial Picture:**
   ```sql
   SELECT
     bs.ticker,
     bs.reporting_date,
     bs.totalassets,
     inc.totalrevenue,
     inc.netincome,
     cf.operatingcashflow
   FROM users.david_huang.cfa_balance_sheet bs
   JOIN users.david_huang.cfa_income_statement inc
     ON bs.ticker = inc.ticker AND bs.reporting_date = inc.reporting_date
   JOIN users.david_huang.cfa_cashflow cf
     ON bs.ticker = cf.ticker AND bs.reporting_date = cf.reporting_date
   ```

## Data Notes

- Financial statement data (balance sheet, income statement, cashflow) is reported quarterly or annually
- Stock price data is daily
- All monetary values are in the currency specified by `reportedcurrency`
- NULL values may appear when data is not available or not applicable
- Reporting dates may vary by company (different fiscal year ends)
