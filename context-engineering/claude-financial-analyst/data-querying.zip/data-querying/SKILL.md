---
name: data-querying
description: This skill should be used when querying financial data from Databricks for financial analysis tasks. Use this skill when completing financial analysis that requires accessing stock prices, balance sheets, income statements, or cash flow data from the Databricks Unity Catalog tables.
---

# Data Querying

## Overview

This skill provides instructions for querying financial data from Databricks using the dbsql-mcp MCP server. The data is stored in Unity Catalog and consists of four tables containing stock price data and fundamental financial statements needed for comprehensive financial analysis.

## When to Use This Skill

Use this skill when:
- Completing financial analysis tasks that require querying data from Databricks
- A user asks questions about stock prices, financial statements, or company fundamentals
- Conducting ratio analysis, trend analysis, or comparative analysis across companies
- Building financial models that require historical data
- Performing valuation analysis or due diligence research

## Available Data

Four financial data tables are available in the `users.david_huang` schema:

1. **cfa_stock_price** - Daily stock price data (OHLC + volume)
2. **cfa_balance_sheet** - Quarterly/annual balance sheet statements
3. **cfa_income_statement** - Quarterly/annual income statements
4. **cfa_cashflow** - Quarterly/annual cash flow statements

For detailed schema information including all columns, data types, and relationships, reference `references/schema.md`.

## Using the dbsql-mcp MCP Server

### Available Tools

Three tools are available through the dbsql-mcp MCP server:

1. **mcp__dbsql-mcp__execute_sql_read_only** - Execute read-only SQL queries (SELECT, SHOW, DESCRIBE)
2. **mcp__dbsql-mcp__execute_sql** - Execute any SQL including INSERT, UPDATE, CREATE (NOT to be used in this skill)
3. **mcp__dbsql-mcp__poll_sql_result** - Poll for results of long-running queries

### Query Guidelines

**IMPORTANT: Only use read-only queries**
- Always use `mcp__dbsql-mcp__execute_sql_read_only` for querying data
- Never use `mcp__dbsql-mcp__execute_sql` as it allows write operations
- Do not attempt CREATE, INSERT, UPDATE, DELETE, or any data modification statements

**Use fully qualified table names**
- Always use the three-level Unity Catalog namespace: `users.david_huang.<table_name>`
- Example: `SELECT * FROM users.david_huang.cfa_stock_price`
- Never omit the catalog and schema portions

**Escape special characters**
- Use backticks for names with special characters: `users`.`david_huang`.`table-name`
- Standard table names (letters/numbers/underscores) do not require backticks

**Query best practices**
- Use WHERE clauses to filter by ticker and date ranges for better performance
- Join financial statement tables on ticker and reporting_date
- Join stock prices to statements using date range conditions (price date >= reporting date)
- Order results appropriately for time-series analysis

## Common Query Patterns

### 1. Stock Price Queries

**Latest price for a ticker:**
```sql
SELECT ticker, date, close, volume
FROM users.david_huang.cfa_stock_price
WHERE ticker = 'AAPL'
ORDER BY date DESC
LIMIT 1
```

**Price history over date range:**
```sql
SELECT date, ticker, open, high, low, close, volume
FROM users.david_huang.cfa_stock_price
WHERE ticker = 'AAPL'
  AND date BETWEEN '2023-01-01' AND '2024-01-01'
ORDER BY date
```

**Multiple tickers comparison:**
```sql
SELECT ticker, date, close
FROM users.david_huang.cfa_stock_price
WHERE ticker IN ('AAPL', 'MSFT', 'GOOGL')
  AND date >= '2023-01-01'
ORDER BY date, ticker
```

### 2. Financial Statement Queries

**Latest balance sheet:**
```sql
SELECT *
FROM users.david_huang.cfa_balance_sheet
WHERE ticker = 'AAPL'
ORDER BY reporting_date DESC
LIMIT 1
```

**Revenue trend analysis:**
```sql
SELECT reporting_date, ticker, totalrevenue, netincome
FROM users.david_huang.cfa_income_statement
WHERE ticker = 'AAPL'
ORDER BY reporting_date
```

**Complete financial snapshot:**
```sql
SELECT
  bs.ticker,
  bs.reporting_date,
  bs.totalassets,
  bs.totalliabilities,
  bs.totalshareholderequity,
  inc.totalrevenue,
  inc.netincome,
  inc.ebitda,
  cf.operatingcashflow,
  cf.capitalexpenditures
FROM users.david_huang.cfa_balance_sheet bs
JOIN users.david_huang.cfa_income_statement inc
  ON bs.ticker = inc.ticker
  AND bs.reporting_date = inc.reporting_date
JOIN users.david_huang.cfa_cashflow cf
  ON bs.ticker = cf.ticker
  AND bs.reporting_date = cf.reporting_date
WHERE bs.ticker = 'AAPL'
ORDER BY bs.reporting_date DESC
```

### 3. Ratio Calculations

**Liquidity ratios:**
```sql
SELECT
  ticker,
  reporting_date,
  totalcurrentassets / totalcurrentliabilities AS current_ratio,
  (totalcurrentassets - inventory) / totalcurrentliabilities AS quick_ratio
FROM users.david_huang.cfa_balance_sheet
WHERE ticker = 'AAPL'
ORDER BY reporting_date DESC
```

**Profitability margins:**
```sql
SELECT
  ticker,
  reporting_date,
  grossprofit / totalrevenue AS gross_margin,
  operatingincome / totalrevenue AS operating_margin,
  netincome / totalrevenue AS net_margin
FROM users.david_huang.cfa_income_statement
WHERE ticker = 'AAPL'
  AND totalrevenue > 0
ORDER BY reporting_date DESC
```

**Free cash flow:**
```sql
SELECT
  ticker,
  reporting_date,
  operatingcashflow,
  capitalexpenditures,
  operatingcashflow - capitalexpenditures AS free_cash_flow
FROM users.david_huang.cfa_cashflow
WHERE ticker = 'AAPL'
ORDER BY reporting_date DESC
```

### 4. Multi-Company Analysis

**Compare companies on key metrics:**
```sql
SELECT
  bs.ticker,
  bs.reporting_date,
  bs.totalassets,
  inc.totalrevenue,
  inc.netincome,
  inc.netincome / inc.totalrevenue AS net_margin,
  bs.totalliabilities / bs.totalassets AS leverage_ratio
FROM users.david_huang.cfa_balance_sheet bs
JOIN users.david_huang.cfa_income_statement inc
  ON bs.ticker = inc.ticker
  AND bs.reporting_date = inc.reporting_date
WHERE bs.ticker IN ('AAPL', 'MSFT', 'GOOGL')
  AND bs.reporting_date = (
    SELECT MAX(reporting_date)
    FROM users.david_huang.cfa_balance_sheet
    WHERE ticker = bs.ticker
  )
```

### 5. Discovery Queries

**Check available tickers:**
```sql
SELECT DISTINCT ticker
FROM users.david_huang.cfa_stock_price
ORDER BY ticker
```

**Date range for a ticker:**
```sql
SELECT
  ticker,
  MIN(date) AS first_date,
  MAX(date) AS last_date,
  COUNT(*) AS trading_days
FROM users.david_huang.cfa_stock_price
WHERE ticker = 'AAPL'
GROUP BY ticker
```

**Latest reporting dates by ticker:**
```sql
SELECT
  ticker,
  MAX(reporting_date) AS latest_report
FROM users.david_huang.cfa_balance_sheet
GROUP BY ticker
ORDER BY ticker
```

## Workflow for Financial Analysis Queries

When a user requests financial analysis:

1. **Understand the analysis requirements**
   - Identify which companies/tickers are involved
   - Determine the time period needed
   - Clarify which metrics or ratios are required

2. **Reference the schema documentation**
   - Read `references/schema.md` to understand available columns
   - Identify which tables contain the needed data
   - Plan the necessary joins and calculations

3. **Construct the query**
   - Use fully qualified table names: `users.david_huang.<table_name>`
   - Apply appropriate filters (ticker, date ranges)
   - Include necessary joins for cross-statement analysis
   - Calculate derived metrics as needed

4. **Execute using read-only tool**
   - Use `mcp__dbsql-mcp__execute_sql_read_only`
   - Handle any errors by reviewing syntax and table/column names
   - For long-running queries, use `mcp__dbsql-mcp__poll_sql_result` with the returned statement_id

5. **Process and present results**
   - Format results appropriately for analysis
   - Calculate additional metrics if needed
   - Provide context and interpretation based on the financial-analysis skill

## Error Handling

**Table not found errors:**
- Verify using fully qualified names: `users.david_huang.<table>`
- Double-check table name spelling (all tables have `cfa_` prefix except stock price)
- Confirm the table exists with: `SHOW TABLES IN users.david_huang`

**Column not found errors:**
- Reference `references/schema.md` for exact column names
- Use `DESCRIBE TABLE users.david_huang.<table>` to see available columns
- Note that column names are lowercase with no spaces

**Empty results:**
- Check if the ticker exists in the dataset
- Verify the date range overlaps with available data
- Use discovery queries to confirm data availability

## Data Limitations

- Financial statement data is updated manually via `get_financial_data.ipynb` on Databricks
- Do not attempt to trigger data updates as part of this skill
- Data freshness depends on when it was last loaded
- Not all tickers may have complete historical data
- NULL values may appear when specific metrics are not available for a company

## Resources

### references/schema.md
Comprehensive documentation of all four financial data tables including:
- Complete column lists with data types and descriptions
- Primary keys and relationships between tables
- Common query patterns and join examples
- Notes on data characteristics and special considerations

Load this file into context when detailed schema information is needed for query construction.
